const fs = require('fs');
const path = require('path');

// Define output directories (Vercel requires this exact path)
const outputRoot = path.join(__dirname, '.vercel', 'output', 'static');
const assetsOut = path.join(outputRoot, 'assets');

// Create directories
fs.mkdirSync(assetsOut, { recursive: true });

// Copy index.html
fs.copyFileSync('index.html', path.join(outputRoot, 'index.html'));
console.log('Copied index.html');

// Copy style.css and app.js from assets folder
fs.copyFileSync('assets/style.css', path.join(assetsOut, 'style.css'));
console.log('Copied assets/style.css');

fs.copyFileSync('assets/app.js', path.join(assetsOut, 'app.js'));
console.log('Copied assets/app.js');

console.log('Build completed successfully');